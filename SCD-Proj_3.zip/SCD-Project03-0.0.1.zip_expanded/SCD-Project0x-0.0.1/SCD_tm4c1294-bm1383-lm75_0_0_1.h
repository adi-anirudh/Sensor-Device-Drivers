/*
 * remoSensor1_tm4c1294-bm1383_0_0_1.h
 *
 *  Created on: 12-Jul-2022
 *      Author: Harish
 */

#ifndef REMOSENSOR1_TM4C1294_BM1383_LM75_0_0_1_H_
#define REMOSENSOR1_TM4C1294_BM1383_LM75_0_0_1_H_

#include "remoSensor1_BM1383_0_0_3.h"
#include "remoSensor2_LM75_0_0_3.h"
#include "remoDIO.h"

typedef enum State
{
    STATE_INIT,
    STATE_READY,
    STATE_CLIMATE,
    STATE_DATA,
    STATE_COMMAND,
    STATE_ERROR
} State_t;

/*---------------------- I2C Config --------------------------------*/
#define SENSOR_I2C_PERIPH           SYSCTL_PERIPH_I2C0
#define SENSOR_I2C_GPIO_PERIPH      SYSCTL_PERIPH_GPIOB
#define SENSOR_I2C_BASE             I2C0_BASE
#define SENSOR_I2C_GPIO_PORT_BASE   GPIO_PORTB_BASE
#define SENSOR_I2C_SCL_PORT_PIN     GPIO_PIN_2
#define SENSOR_I2C_SDA_PORT_PIN     GPIO_PIN_3
#define SENSOR_I2C_SCL_PIN          GPIO_PB2_I2C0SCL
#define SENSOR_I2C_SDA_PIN          GPIO_PB3_I2C0SDA

void uvm2I2CRecieve(void);


#endif /* REMOSENSOR1_TM4C1294_BM1383_LM75_0_0_1_H_ */
