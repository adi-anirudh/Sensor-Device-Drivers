/*
 * remoUART.h
 *
 *  Created on: 21-Jan-2022
 *      Author: hvkamat
 */

#ifndef REMOUART_H_
#define REMOUART_H_

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "inc/hw_ints.h"

#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"

typedef struct UARTConfig
{
    uint32_t ui32UartBaudrate;
    uint32_t ui32UartDataLen;
    uint32_t ui32UartStopBits;
    uint32_t ui32UartParity;
} uart_config_t;

typedef struct UART
{
    uint32_t ui32UartPeripheral;
    uint32_t ui32UartGpioPeripheral;
    uint32_t ui32UartGpioPort;
    uint32_t ui32UartBase;
    uint32_t ui32UartPortPins;
    uint32_t ui32UartTxPin;
    uint32_t ui32UartRxPin;
    uint32_t ui32UartIrq;
    uint32_t ui32UartIrqFlags;
    uart_config_t ucConfig;
} uart_t;

void uartInit(uart_t);
void uartConfig(uart_t);
void uartInterruptConfig(uart_t uart);
void uartSend (uart_t, const uint8_t *);


#endif /* REMOUART_H_ */
