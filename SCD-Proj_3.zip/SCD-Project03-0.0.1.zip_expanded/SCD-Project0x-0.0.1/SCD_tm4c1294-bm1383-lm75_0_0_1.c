/*
 * SCD_tm4c1294-bm1383-lm75_0_0_1.c
 *
 *  Created on: 17-Jul-2022
 *      Author: Harish
 */
#include <remoSensor1_BM1383_0_0_3.h>
#include <remoSensor2_LM75_0_0_3.h>
#include <SCD_tm4c1294-bm1383-lm75_0_0_1.h>
#include <ec_commands.h>

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "inc/hw_types.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "inc/hw_i2c.h"
#include "inc/hw_ints.h"

#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"

#include "remoUtils.h"
#include "remoI2C.h"
#include "remoUART.h"
#include "remoDIO.h"

// Device
#define MY_ADDR 0x01
#define DEV_HW_VERSION  "1.0.0"
#define DEV_HW_VER_DATE "01/02/2022"
#define DEV_FW_VERSION  "1.0.0"
#define DEV_FW_VER_DATE "01/01/2022"
#define DEV_MODEL       "CS_001"
#define DEV_MANUFACTURER    "Shalaka Connected Devices LLP"

//Climate Sensor Module
    char *devHwVersion= DEV_HW_VERSION;
    char *devHwVersionDate= DEV_HW_VER_DATE;
    char *devFwVersion= DEV_FW_VERSION;
    char *devFwVersionDate= DEV_FW_VER_DATE;
    char *devModel= DEV_MODEL;
    char *devManufacturer= DEV_MANUFACTURER;

    BM1383_t bm1383;
    lm75b_t lm75b;
    led_t ledRed, ledGreen, ledBlue;

    // Sensor I2C module
    i2c_t i2c0={SENSOR_I2C_PERIPH, SENSOR_I2C_GPIO_PERIPH, SENSOR_I2C_GPIO_PORT_BASE, SENSOR_I2C_BASE,
                SENSOR_I2C_SCL_PORT_PIN, SENSOR_I2C_SDA_PORT_PIN, SENSOR_I2C_SCL_PIN, SENSOR_I2C_SDA_PIN};

State_t enumCurrentState, enumPreviousState;

uint32_t g_ui32SysClock;
uint8_t ui8SlaveAddr, ui8Data;
uint8_t ui8Command = CMD_NONE;
char strMessage[64];
char *Title="Climate Sensors\n\r";

bool boolNewData=false;
bool boolNewCommand=false;

int main(void)
{
    //
    // Enable lazy stacking for interrupt handlers.  This allows floating-point
    // instructions to be used within interrupt handlers, but at the expense of
    // extra stack usage.
    //
    g_ui32SysClock=SysCtlClockGet();

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOD));

    /*-------------------------- State Machine Initialisation ----------------------------*/

    enumCurrentState=STATE_INIT;
    enumPreviousState = enumCurrentState;
    while (true)
    {
        switch (enumCurrentState)
        {
        case STATE_INIT:
            /*-------------------------- LED Configuration ----------------------------*/
            // LED Red Configuration
            ledRed.ui32Port=LED_RED_OUTPUT_PORT;
            ledRed.ui8Pin=LED_RED_OUTPUT_PIN;
            remoInitDigital(ledRed.ui32Port, ledRed.ui8Pin, true);
            // Turn OFF LED Red as default
            ledOff(ledRed);

            // LED Green Configuration
            ledGreen.ui32Port=LED_GREEN_OUTPUT_PORT;
            ledGreen.ui8Pin=LED_GREEN_OUTPUT_PIN;
            remoInitDigital(ledGreen.ui32Port, ledGreen.ui8Pin, true);
            // Turn OFF LED Green as default
            ledOff(ledGreen);

            // LED Blue Configuration
            ledBlue.ui32Port=LED_BLUE_OUTPUT_PORT;
            ledBlue.ui8Pin=LED_BLUE_OUTPUT_PIN;
            remoInitDigital(ledBlue.ui32Port, ledBlue.ui8Pin, true);
            // Turn OFF LED Blue as default
            ledOff(ledBlue);

            /*-------------------------- LED Test ----------------------------*/
            ledTest(ledRed);
            SysCtlDelay(1000000);
            ledTest(ledGreen);
            SysCtlDelay(1000000);
            ledTest(ledBlue);
            SysCtlDelay(1000000);



            /*------------------------------ Configure I2C0 -------------------------------*/
            i2cInit(i2c0);

            /*-------------------------- Sensors Identify ----------------------------*/
            bm1383.ui8_ID = BM1383GLV_GetID();
            // LM75B Sensor does not have registers that store Manufacturer and Device ID
            lm75b.ui8_ID = 0x00;

            /*--------------------------Reset the sensors-----------------------------*/
            BM1383GLV_Set();
            LM75BReset();

            /*----------------Set initial default sensor conditions--------------------*/
            BM1383GLV_SetMode();
            //BM1383GLVSetInterrupt();
            LM75BConfig(0x0000);

            /*------------------------- Go to READY State ------------------------------*/
            enumPreviousState = enumCurrentState;
            enumCurrentState=STATE_READY;
            break;

        case STATE_READY:
            /*-------------------------- State Machine READY ----------------------------*/
            ledOn(ledGreen);

            if (boolNewCommand)
                if (ui8Command != CMD_NONE)
                {
                    enumPreviousState = enumCurrentState;
                    enumCurrentState=STATE_COMMAND;
                }
            else
            {
                enumPreviousState = enumCurrentState;
                enumCurrentState=STATE_CLIMATE;
            }
            break;

        case STATE_CLIMATE:
            // Pressure Sensor
            bm1383.Pressure = BM1383GLV_GetPressure();
            // Temperature Sensor
            lm75b.Temperature = LM75BTemperatureRegister();
            enumPreviousState = enumCurrentState;
            enumCurrentState=STATE_READY;
            break;

        case STATE_COMMAND:
            CommandExecute(ui8Command);
            boolNewCommand = false;
            ui8Command = CMD_NONE;
            enumPreviousState = enumCurrentState;
            enumCurrentState=STATE_READY;

        case STATE_DATA:
            enumPreviousState = enumCurrentState;
            enumCurrentState=STATE_READY;
            break;

        case STATE_ERROR:
            break;
        }
    }
}


//UART function re-written using I2C commands depending on what we will be using
void uvm2I2CReceive(void)
{
    uint32_t ui32IntStatus = I2CSlaveIntStatus(SENSOR_I2C_BASE,true);
    // Read data from Rx Buffer to internal buffer
    //ui8SlaveAddr=i2cReceive(SENSOR_I2C_BASE);
    ui8Command = i2cReceive(SENSOR_I2C_BASE,2,SENSOR_I2C_SDA_PIN);
    //ui8Data = i2cReceive(SENSOR_I2C_BASE);
    boolNewCommand = true;
    enumPreviousState = enumCurrentState;
    enumCurrentState=STATE_READY;
    I2CSlaveIntClear(SENSOR_I2C_BASE);
}




