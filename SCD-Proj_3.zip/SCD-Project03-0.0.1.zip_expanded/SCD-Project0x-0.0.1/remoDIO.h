/*
 * remoDIO.h
 *
 *  Created on: 22-Jan-2022
 *      Author: hvkamat
 */

#ifndef REMODIO_H_
#define REMODIO_H_
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "inc/hw_ints.h"

#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"

#include "remoUtils.h"
void remoInitDigital(uint32_t, uint8_t, bool);
void remoSetDigital(uint32_t, uint8_t);
void remoClearDigital(uint32_t, uint8_t);
void remoToggleDigital(uint32_t, uint8_t);
bool remoGetDigital(uint32_t, uint8_t);
bool remoIsDigitalHigh(uint32_t, uint8_t);

// LED Red Control
#define LED_RED_OUTPUT_PORT GPIO_PORTF_BASE         // Red LED on TM4C123GXL LP
#define LED_RED_OUTPUT_PIN  GPIO_PIN_1

// LED Green Control
#define LED_GREEN_OUTPUT_PORT GPIO_PORTF_BASE       // Green LED on TM4C123GXL LP
#define LED_GREEN_OUTPUT_PIN  GPIO_PIN_3

// LED Blue Control
#define LED_BLUE_OUTPUT_PORT GPIO_PORTF_BASE        // Blue LED on TM4C123GXL LP
#define LED_BLUE_OUTPUT_PIN  GPIO_PIN_2

typedef enum LEDState
{
    LED_ON,
    LED_OFF,
    LED_BLINK_SLOW,
    LED_BLINK_FAST
}led_state_t;

typedef struct Led
{
    uint32_t ui32Port;
    uint8_t ui8Pin;
    led_state_t enumState;
}led_t;

void ledOn(led_t);
void ledOff(led_t);
bool ledTest(led_t);

#endif /* REMODIO_H_ */
