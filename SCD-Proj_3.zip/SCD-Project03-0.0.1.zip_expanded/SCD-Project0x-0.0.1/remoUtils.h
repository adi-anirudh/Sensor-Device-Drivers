#define LOWBYTE(x)   ((uint8_t) (x))
#define HIGHBYTE(x)  ((uint8_t) ((x) >> 8))

#define LOWWORD(v)   ((uint16_t) (v))
#define HIGHWORD(v)  ((uint16_t) (((uint32_t) (v)) >> 16))
