/*
 * ec_commands.h
 *
 *  Created on: 17-Jul-2022
 *      Author: Harish
 */

#ifndef EC_COMMANDS_H_
#define EC_COMMANDS_H_
#include <stdint.h>
#include <stdbool.h>

#define  CMD_NONE           0x00
#define  CMD_GET_DEV_INFO   0x01
#define  CMD_GET_CLIMATE    0x02
#define  CMD_ERROR          0xFF

#define CLIMATE_MSG "{\"action\": \"sensor-03\",\"result\": \"OK\",\"data\":[\"temperature\": \"%2.1fC\",\"humidity\": \"%03.0f%%\", \"pressure\": \"%04xhpa\"]}\n"
#define DEV_INFO    "{\"hw_version\":\"%s\"\"fw_version\":\"%s\"}\n"

void CommandExecute(uint8_t);







#endif /* EC_COMMANDS_H_ */
