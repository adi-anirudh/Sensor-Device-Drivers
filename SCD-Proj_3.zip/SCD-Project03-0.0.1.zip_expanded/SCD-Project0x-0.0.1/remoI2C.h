/*
 * remoI2C.h
 *
 *  Created on: 10-Dec-2021
 *      Author: hvkamat
 */

#ifndef REMOI2C_H_
#define REMOI2C_H_

typedef struct I2C
{
    uint32_t ui32I2CPeripheral;
    uint32_t ui32I2CGpioPeripheral;
    uint32_t ui32I2CGpioPort;
    uint32_t ui32I2CBase;
    uint32_t ui32I2CSCLPortPin;
    uint32_t ui32I2CSDAPortPin;
    uint32_t ui32I2CSclPin;
    uint32_t ui32I2CSdaPin;
} i2c_t;


void i2cInit(i2c_t);
void i2cSend(uint8_t, uint32_t, ...);
uint32_t i2cReceive(uint32_t slave_addr, uint32_t num_of_args, uint8_t reg);

#endif /* REMOI2C_H_ */
